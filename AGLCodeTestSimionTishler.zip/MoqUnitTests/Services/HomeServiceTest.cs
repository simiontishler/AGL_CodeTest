﻿using AGL_SimionTishler_Code_Test.Interfaces;
using AGL_SimionTishler_Code_Test.Models;
using AGL_SimionTishler_Code_Test.ModelViews;
using AGL_SimionTishler_Code_Test.Services;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace MoqUnitTests.Services
{
    public class HomeServiceTest
    {
        HomeService service;

        public HomeServiceTest()
        {
             service = new HomeService();
        }

        [Fact]
        public void FindHumansWithCats_DoesHaveCats_ReturnsNull()
        {


            // Arrange

            var humanList = new List<Humans>
            {
                new Humans
                {
                    gender = "Male",
                    pets = new List<Pets>
                    {
                         new Pets
                         {
                             name = "Pooky",
                             type = "Dog"
                         }
                    }
                }
            };

            // Act
            List<HumansWithCats> result = service.FindHumansWithCats(humanList);

            // Assert          

            Assert.Null( result[0].cats);
        }

        [Fact]
        public void FindHumansWithCats_DoesHaveCats_ReturnsNotNull()
        {


            // Arrange

            var humanList = new List<Humans>
            {
                new Humans
                {
                    gender = "Male",
                    pets = new List<Pets>
                    {
                         new Pets
                         {
                             name = "Pooky",
                             type = "Cat"
                         }
                    }
                }
            };

            // Act
            List<HumansWithCats> result = service.FindHumansWithCats(humanList);

            // Assert          

            Assert.NotNull( result[0].cats);
        }

        [Fact]
        public void FindHumansWithCats_DoesHaveFemales_ReturnsNull()
        {


            // Arrange

            var humanList = new List<Humans>
            {
                new Humans
                {
                    gender = "Male",
                    pets = new List<Pets>
                    {
                         new Pets
                         {
                             name = "Pooky",
                             type = "Cat"
                         }
                    }
                }
            };

            // Act
            List<HumansWithCats> result = service.FindHumansWithCats(humanList);

            // Assert          
            var test = result.Find(x => x.gender == "Female");

            Assert.Null( test);
        }
    }
}
