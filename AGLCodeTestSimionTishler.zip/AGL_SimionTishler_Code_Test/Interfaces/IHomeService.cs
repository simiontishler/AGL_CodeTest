﻿using AGL_SimionTishler_Code_Test.Models;
using AGL_SimionTishler_Code_Test.ModelViews;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AGL_SimionTishler_Code_Test.Interfaces
{
    public interface IHomeService
    {
        Task<IEnumerable<HumansWithCats>> GetHumansWithCats(string baseUrl);
        List<HumansWithCats> FindHumansWithCats(IEnumerable<Humans> humans);
    }
}
