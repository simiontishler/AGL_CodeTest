import { Component, Inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  templateUrl: './home.component.html'
})
export class HomeComponent {
  public humans: HumansWithCats[];

  constructor(http: HttpClient, @Inject('BASE_URL') baseUrl: string) {
    http.get<HumansWithCats[]>(baseUrl + 'api/HomeController/GetHumansCatList').subscribe(result => {
      this.humans = result;
    }, error => console.error(error));
  }
}

interface Cats {
  name: string;
} 

interface HumansWithCats {
  gender: string;
  cats: Cats[]
}
