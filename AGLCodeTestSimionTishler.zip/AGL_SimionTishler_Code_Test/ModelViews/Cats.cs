﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AGL_SimionTishler_Code_Test.ModelViews
{
    public class Cats
    {
        public string name { get; set; }
    }
}
