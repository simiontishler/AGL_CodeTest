using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using AGL_SimionTishler_Code_Test.Models;
using AGL_SimionTishler_Code_Test.ModelViews;
using AGL_SimionTishler_Code_Test.Services;
using Microsoft.AspNetCore.Mvc;
using AGL_SimionTishler_Code_Test.Interfaces;

namespace AGL_SimionTishler_Code_Test.Controllers
{
    [Produces("application/json")]
    [Route("api/HomeController")]
    public class HomeController : Controller
    {
        private HomeService homeService = new HomeService();
        public HomeController(IHomeService homeService)
        { }

        [HttpGet("[action]")]
        public IEnumerable<HumansWithCats> GetHumansCatList()
        {
            //Define your baseUrl
            string baseUrl = "http://agl-developer-test.azurewebsites.net/people.json";

            if (homeService == null)
                return new List<HumansWithCats>();

            IEnumerable<HumansWithCats> human = homeService.GetHumansWithCats(baseUrl).Result;
            return human;        
        }
    }
}
