﻿using AGL_SimionTishler_Code_Test.Models;
using AGL_SimionTishler_Code_Test.ModelViews;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using AGL_SimionTishler_Code_Test.Interfaces;

namespace AGL_SimionTishler_Code_Test.Services
{
    public class HomeService : IHomeService
    { 
        public async Task<IEnumerable<HumansWithCats>> GetHumansWithCats(string baseUrl)
        {
            IEnumerable<Humans> humans = new List<Humans>();
                       
            //Have your using statements within a try/catch blokc that will catch any exceptions.
            try
            {
                //We will now define your HttpClient with your first using statement which will use a IDisposable.
                using (HttpClient client = new HttpClient())
                {
                    //In the next using statement you will initiate the Get Request, use the await keyword so it will execute the using statement in order.
                    using (HttpResponseMessage res = await client.GetAsync(baseUrl))
                    {
                        //Then get the content from the response in the next using statement, then within it you will get the data, and convert it to a c# object.
                        using (HttpContent content = res.Content)
                        {
                            //Now assign your content to your data variable, by converting into a string using the await keyword.
                            var data = await content.ReadAsStringAsync();
                            //If the data isn't null return log convert the data using newtonsoft JObject Parse class method on the data.
                            if (data != null)
                            {
                                humans = JsonConvert.DeserializeObject<List<Humans>>(data);
                            }
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine("Exception Hit------------");
                Console.WriteLine(exception);
            }

            return FindHumansWithCats(humans);
        }

        public List<HumansWithCats> FindHumansWithCats(IEnumerable<Humans> humans)
        {
            List<HumansWithCats> humansWithCats = new List<HumansWithCats>();

            humansWithCats = humans.GroupBy(x => x.gender).Select(y=> new HumansWithCats { gender = y.Key}).ToList();

            try
            { 
                foreach (Humans human in humans)
                {
                    if (human.pets != null)
                    {
                        foreach (Pets pet in human.pets)
                        {
                            if (pet.type == "Cat" && human.gender == "Male")
                            {
                                var males = humansWithCats.Find(x => x.gender == "Male");
                                if (males.cats == null)
                                    males.cats = new List<Cats>();

                                males.cats.Add(new Cats { name = pet.name });
                            }
                            if (pet.type == "Cat" && human.gender == "Female")
                            {
                                var female = humansWithCats.Find(x => x.gender == "Female");
                                if (female.cats == null)
                                    female.cats = new List<Cats>();

                                female.cats.Add(new Cats { name = pet.name });
                            }
                        }
                    }
                }
            }
            catch (Exception exception)
            {
                Console.WriteLine("Exception Hit------------");
                Console.WriteLine(exception);
            }

            return humansWithCats;
        }

        
    }   
}
